import React, { useState, useEffect } from 'react';
import { Menu, Instagram, Facebook, MessageCircle, X } from 'lucide-react';
import LanguageSwitcher from './LanguageSwitcher';
import { useLanguage } from '../contexts/LanguageContext';

const SOCIAL_LINKS = {
  instagram: 'https://www.instagram.com/viento_tattoos/',
  facebook: 'https://www.facebook.com/tamy.avila.g/',
  whatsapp: 'https://wa.me/14385314235'
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-obsidian-900/95 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex-shrink-0">
            <span className="font-cinzel text-2xl font-bold metallic-text">Viento Tattoos</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#about" className="nav-link">{t('about')}</a>
            <a href="#gallery" className="nav-link">{t('gallery')}</a>
            <a href="#services" className="nav-link">{t('services')}</a>
            <a href="#booking" className="nav-link">{t('booking')}</a>
            
            <div className="flex items-center space-x-4 ml-8">
              <LanguageSwitcher />
              <a href={SOCIAL_LINKS.instagram} target="_blank" rel="noopener noreferrer"
                 className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
                <Instagram size={20} />
              </a>
              <a href={SOCIAL_LINKS.facebook} target="_blank" rel="noopener noreferrer"
                 className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
                <Facebook size={20} />
              </a>
              <a href={SOCIAL_LINKS.whatsapp} target="_blank" rel="noopener noreferrer"
                 className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
                <MessageCircle size={20} />
              </a>
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)}
                    className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden transition-all duration-300 ${
        isOpen ? 'opacity-100 h-screen' : 'opacity-0 h-0'
      } bg-obsidian-900/95 backdrop-blur-sm`}>
        <div className="px-4 pt-2 pb-8 space-y-4">
          <a href="#about" className="block py-2 text-gray-300 hover:text-gold-400"
             onClick={() => setIsOpen(false)}>{t('about')}</a>
          <a href="#gallery" className="block py-2 text-gray-300 hover:text-gold-400"
             onClick={() => setIsOpen(false)}>{t('gallery')}</a>
          <a href="#services" className="block py-2 text-gray-300 hover:text-gold-400"
             onClick={() => setIsOpen(false)}>{t('services')}</a>
          <a href="#booking" className="block py-2 text-gray-300 hover:text-gold-400"
             onClick={() => setIsOpen(false)}>{t('booking')}</a>
          
          <div className="flex items-center space-x-6 pt-4">
            <LanguageSwitcher />
            <a href={SOCIAL_LINKS.instagram} target="_blank" rel="noopener noreferrer"
               className="text-gray-300 hover:text-gold-400">
              <Instagram size={24} />
            </a>
            <a href={SOCIAL_LINKS.facebook} target="_blank" rel="noopener noreferrer"
               className="text-gray-300 hover:text-gold-400">
              <Facebook size={24} />
            </a>
            <a href={SOCIAL_LINKS.whatsapp} target="_blank" rel="noopener noreferrer"
               className="text-gray-300 hover:text-gold-400">
              <MessageCircle size={24} />
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;