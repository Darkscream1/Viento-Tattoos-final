import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface LanguageDropdownProps {
  isOpen: boolean;
  currentLanguage: string;
  onLanguageSelect: (lang: 'es' | 'fr' | 'en') => void;
}

export const LanguageDropdown = ({ isOpen, currentLanguage, onLanguageSelect }: LanguageDropdownProps) => {
  const languages = [
    { code: 'es', label: 'ES' },
    { code: 'fr', label: 'FR' },
    { code: 'en', label: 'EN' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          className="absolute right-0 mt-2 py-2 w-24 bg-obsidian-800 rounded-md shadow-lg ring-1 ring-black ring-opacity-5"
        >
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => onLanguageSelect(lang.code as 'es' | 'fr' | 'en')}
              className={`block w-full px-4 py-2 text-sm text-left transition-colors duration-300
                ${currentLanguage === lang.code ? 'text-gold-400' : 'text-gray-300 hover:text-gold-400'}`}
            >
              {lang.label}
            </button>
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
};