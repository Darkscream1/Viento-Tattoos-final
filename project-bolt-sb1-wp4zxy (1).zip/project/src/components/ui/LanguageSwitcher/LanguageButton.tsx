import React from 'react';
import { Globe } from 'lucide-react';

interface LanguageButtonProps {
  language: string;
  onClick: () => void;
}

export const LanguageButton = ({ language, onClick }: LanguageButtonProps) => {
  return (
    <button
      onClick={onClick}
      className="flex items-center space-x-1 text-gray-300 hover:text-gold-400 transition-colors duration-300"
    >
      <Globe size={20} />
      <span className="text-sm font-medium">{language.toUpperCase()}</span>
    </button>
  );
};