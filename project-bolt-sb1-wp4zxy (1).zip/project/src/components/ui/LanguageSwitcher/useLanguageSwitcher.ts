import { useState } from 'react';
import { useLanguage } from '../../../contexts/LanguageContext';

export const useLanguageSwitcher = () => {
  const { language, setLanguage } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageChange = (newLanguage: 'es' | 'fr' | 'en') => {
    setLanguage(newLanguage);
    setIsOpen(false);
  };

  return {
    isOpen,
    setIsOpen,
    language,
    handleLanguageChange,
  };
};