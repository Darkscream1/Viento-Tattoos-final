import React from 'react';
import { LanguageButton } from './LanguageButton';
import { LanguageDropdown } from './LanguageDropdown';
import { useLanguageSwitcher } from './useLanguageSwitcher';

export const LanguageSwitcher = () => {
  const { isOpen, setIsOpen, language, handleLanguageChange } = useLanguageSwitcher();

  return (
    <div className="relative">
      <LanguageButton language={language} onClick={() => setIsOpen(!isOpen)} />
      <LanguageDropdown
        isOpen={isOpen}
        currentLanguage={language}
        onLanguageSelect={handleLanguageChange}
      />
    </div>
  );
};