import React from 'react';
import { motion } from 'framer-motion';

interface ButtonProps {
  href?: string;
  variant?: 'primary' | 'secondary';
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const Button = ({ 
  href, 
  variant = 'primary', 
  children, 
  className = '',
  onClick
}: ButtonProps) => {
  const baseClasses = 'inline-flex items-center px-8 py-3 rounded-md font-medium tracking-wide transition-all duration-300';
  const variantClasses = {
    primary: 'bg-black border-2 border-gold-400 text-gold-400 hover:bg-gold-400 hover:text-black',
    secondary: 'bg-obsidian-800 text-gray-300 hover:bg-gold-400/20',
  };

  const buttonContent = (
    <motion.span
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
    >
      {children}
    </motion.span>
  );

  if (href) {
    return (
      <a href={href}>
        {buttonContent}
      </a>
    );
  }

  return (
    <button onClick={onClick}>
      {buttonContent}
    </button>
  );
};