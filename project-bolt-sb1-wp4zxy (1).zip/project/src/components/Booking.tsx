import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';

const WHATSAPP_NUMBER = '14385314235';

const Booking = () => {
  return (
    <section id="booking" className="py-20 bg-obsidian-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="section-title">Reservas</h2>
        
        <div className="max-w-2xl mx-auto text-center">
          <p className="text-gray-300 mb-8 text-lg">
            ¿Tienes preguntas o quieres agendar tu cita? Escríbeme directamente aquí.
          </p>
          
          <motion.a
            href={`https://wa.me/${WHATSAPP_NUMBER}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-3 btn-primary"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <MessageCircle className="w-5 h-5" />
            <span>Contactar por WhatsApp</span>
          </motion.a>
        </div>
      </div>
    </section>
  );
};

export default Booking;