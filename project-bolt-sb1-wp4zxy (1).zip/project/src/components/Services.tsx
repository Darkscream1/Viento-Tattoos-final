import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Palette, Leaf, Pencil, Heart } from 'lucide-react';

const services = [
  {
    icon: Pencil,
    title: 'Diseños Personalizados',
    description: 'Transforma tus ideas en arte único para tu piel.',
  },
  {
    icon: Heart,
    title: 'Líneas Finas',
    description: 'Precisión y delicadeza en cada trazo.',
  },
  {
    icon: Palette,
    title: 'Microrealismo',
    description: 'Detalles sorprendentes en espacios pequeños.',
  },
  {
    icon: Leaf,
    title: 'Botánico y Color',
    description: 'Inspiración natural con vibrantes toques artísticos.',
  },
];

const Services = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="services" className="py-20 bg-obsidian-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="section-title">Servicios</h2>
        
        <div
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-obsidian-900 p-6 rounded-lg hover:transform hover:-translate-y-2 transition-all duration-300"
            >
              <div className="w-12 h-12 bg-gold-400 rounded-lg flex items-center justify-center mb-4">
                <service.icon className="w-6 h-6 text-obsidian-900" />
              </div>
              <h3 className="text-xl font-cinzel font-bold text-gold-400 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-300">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a href="#booking" className="btn-primary">
            Reserva tu cita
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;