import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { Section } from '../../ui/Section';
import { Button } from '../../ui/Button';

const WHATSAPP_NUMBER = '14385314235';

const Booking = () => {
  const { t } = useLanguage();

  return (
    <Section id="booking" className="bg-obsidian-900">
      <h2 className="section-title">{t('booking')}</h2>
      
      <div className="max-w-2xl mx-auto text-center">
        <p className="text-gray-300 mb-8 text-lg">
          {t('bookingTitle')}
        </p>
        
        <motion.a
          href={`https://wa.me/${WHATSAPP_NUMBER}`}
          target="_blank"
          rel="noopener noreferrer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button variant="primary" className="inline-flex items-center space-x-3">
            <MessageCircle className="w-5 h-5" />
            <span>{t('contactMe')}</span>
          </Button>
        </motion.a>
      </div>
    </Section>
  );
};

export default Booking;