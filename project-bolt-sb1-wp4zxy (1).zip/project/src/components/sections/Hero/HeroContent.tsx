import React from 'react';
import { HeroTitle } from './HeroTitle';
import { HeroSubtitle } from './HeroSubtitle';
import { Button } from '../../ui/Button';
import { useLanguage } from '../../../contexts/LanguageContext';

export const HeroContent = () => {
  const { t } = useLanguage();

  return (
    <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col justify-center items-center text-center">
      <HeroTitle />
      <HeroSubtitle />
      <Button href="#booking" variant="primary">
        {t('bookNow')}
      </Button>
    </div>
  );
};