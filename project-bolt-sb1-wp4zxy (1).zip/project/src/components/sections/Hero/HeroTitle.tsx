import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../../../contexts/LanguageContext';

export const HeroTitle = () => {
  const { t } = useLanguage();
  
  return (
    <motion.h1
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="font-cinzel text-4xl md:text-6xl font-bold mb-6 metallic-text"
    >
      {t('heroTitle')}
    </motion.h1>
  );
};