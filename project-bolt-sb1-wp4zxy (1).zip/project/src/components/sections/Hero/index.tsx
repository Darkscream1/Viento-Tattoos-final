import React from 'react';
import { HeroContent } from './HeroContent';
import { HeroBackground } from './HeroBackground';

const Hero = () => {
  return (
    <div className="relative h-screen">
      <HeroBackground />
      <HeroContent />
    </div>
  );
};

export default Hero;