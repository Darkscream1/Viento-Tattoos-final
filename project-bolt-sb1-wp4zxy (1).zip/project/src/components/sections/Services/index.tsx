import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Palette, Leaf, Pencil, Heart } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { Section } from '../../ui/Section';
import { Button } from '../../ui/Button';

const Services = () => {
  const { t } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const services = [
    {
      icon: Pencil,
      title: t('customDesigns'),
      description: t('customDesignsDesc'),
    },
    {
      icon: Heart,
      title: t('fineLines'),
      description: t('fineLinesDesc'),
    },
    {
      icon: Palette,
      title: t('microrealism'),
      description: t('microrealismDesc'),
    },
    {
      icon: Leaf,
      title: t('botanical'),
      description: t('botanicalDesc'),
    },
  ];

  return (
    <Section id="services" className="bg-obsidian-800">
      <h2 className="section-title">{t('services')}</h2>
      
      <div
        ref={ref}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
      >
        {services.map((service, index) => (
          <motion.div
            key={service.title}
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="bg-obsidian-900 p-6 rounded-lg hover:transform hover:-translate-y-2 transition-all duration-300"
          >
            <div className="w-12 h-12 bg-gold-400 rounded-lg flex items-center justify-center mb-4">
              <service.icon className="w-6 h-6 text-obsidian-900" />
            </div>
            <h3 className="text-xl font-cinzel font-bold text-gold-400 mb-3">
              {service.title}
            </h3>
            <p className="text-gray-300">
              {service.description}
            </p>
          </motion.div>
        ))}
      </div>

      <div className="mt-12 text-center">
        <Button href="#booking" variant="primary">
          {t('bookNow')}
        </Button>
      </div>
    </Section>
  );
};

export default Services;