export const categories = ['Todos', 'Líneas Finas', 'Microrealismo', 'Botánico', 'Color'];

export const galleryItems = [
  {
    id: 1,
    category: 'Líneas Finas',
    image: 'https://images.unsplash.com/photo-1611501275019-9b5cda994e8d?w=800&auto=format&fit=crop&q=60',
    title: 'Diseño Geométrico',
    description: 'Líneas precisas que crean patrones geométricos únicos',
  },
  {
    id: 2,
    category: 'Botánico',
    image: 'https://images.unsplash.com/photo-1610634764526-fe62fc0e4966?w=800&auto=format&fit=crop&q=60',
    title: 'Flores Silvestres',
    description: 'Composición botánica con detalles naturales',
  },
  {
    id: 3,
    category: 'Microrealismo',
    image: 'https://images.unsplash.com/photo-1612615767439-c54bc04ff37d?w=800&auto=format&fit=crop&q=60',
    title: 'Retrato Miniatura',
    description: 'Detallado trabajo de microrealismo',
  },
  {
    id: 4,
    category: 'Color',
    image: 'https://images.unsplash.com/photo-1590246814883-57c511e76523?w=800&auto=format&fit=crop&q=60',
    title: 'Acuarela Abstracta',
    description: 'Explosión de colores en estilo acuarela',
  },
  {
    id: 5,
    category: 'Líneas Finas',
    image: 'https://images.unsplash.com/photo-1562962230-16e4623d36e6?w=800&auto=format&fit=crop&q=60',
    title: 'Mandala Minimalista',
    description: 'Patrones delicados con líneas finas y precisas',
  },
  {
    id: 6,
    category: 'Botánico',
    image: 'https://images.unsplash.com/photo-1611501633407-dd3d89e0f459?w=800&auto=format&fit=crop&q=60',
    title: 'Rosas Salvajes',
    description: 'Composición floral con estilo botánico detallado',
  },
  {
    id: 7,
    category: 'Microrealismo',
    image: 'https://images.unsplash.com/photo-1578301978693-85fa9c0320b9?w=800&auto=format&fit=crop&q=60',
    title: 'Retrato Natural',
    description: 'Microrealismo con atención al detalle y textura',
  },
  {
    id: 8,
    category: 'Color',
    image: 'https://images.unsplash.com/photo-1610634764395-5458d6e7d46f?w=800&auto=format&fit=crop&q=60',
    title: 'Explosión Cromática',
    description: 'Diseño vibrante con mezcla de colores',
  },
  {
    id: 9,
    category: 'Líneas Finas',
    image: 'https://images.unsplash.com/photo-1562962231-6766c51c5a51?w=800&auto=format&fit=crop&q=60',
    title: 'Geometría Sagrada',
    description: 'Patrones geométricos con significado simbólico',
  },
  {
    id: 10,
    category: 'Botánico',
    image: 'https://images.unsplash.com/photo-1611501633680-82e7a923d985?w=800&auto=format&fit=crop&q=60',
    title: 'Jardín Silvestre',
    description: 'Composición natural con elementos botánicos',
  },
  {
    id: 11,
    category: 'Microrealismo',
    image: 'https://images.unsplash.com/photo-1578301978018-927731d2b8e9?w=800&auto=format&fit=crop&q=60',
    title: 'Detalle Animal',
    description: 'Microrealismo con enfoque en la fauna',
  },
  {
    id: 12,
    category: 'Color',
    image: 'https://images.unsplash.com/photo-1590246814926-3e6ae8286b6d?w=800&auto=format&fit=crop&q=60',
    title: 'Acuarela Onírica',
    description: 'Fusión de colores en estilo acuarela',
  }
];