import React from 'react';
import { motion } from 'framer-motion';

interface GalleryItemProps {
  item: {
    id: number;
    image: string;
    title: string;
    description: string;
  };
  index: number;
  inView: boolean;
  onSelect: (id: number) => void;
}

export const GalleryItem = ({ item, index, inView, onSelect }: GalleryItemProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group relative cursor-pointer"
      onClick={() => onSelect(item.id)}
    >
      <div className="aspect-w-3 aspect-h-4 relative overflow-hidden rounded-lg">
        <img
          src={item.image}
          alt={item.title}
          className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <h3 className="text-xl font-cinzel font-bold text-gold-400 mb-2">
              {item.title}
            </h3>
            <p className="text-gray-300">
              {item.description}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};