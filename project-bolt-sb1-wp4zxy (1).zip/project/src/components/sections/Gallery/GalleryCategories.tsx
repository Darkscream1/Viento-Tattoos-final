import React from 'react';

interface GalleryCategoriesProps {
  categories: string[];
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
}

export const GalleryCategories = ({ 
  categories, 
  selectedCategory, 
  onCategorySelect 
}: GalleryCategoriesProps) => {
  return (
    <div className="flex flex-wrap justify-center gap-4 mb-12">
      {categories.map((category) => (
        <button
          key={category}
          onClick={() => onCategorySelect(category)}
          className={`px-6 py-2 rounded-full transition-all duration-300 ${
            selectedCategory === category
              ? 'bg-gold-400 text-black'
              : 'bg-obsidian-800 text-gray-300 hover:bg-gold-400/20'
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  );
};