import { useState } from 'react';
import { useInView } from 'react-intersection-observer';

export const useGallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return {
    selectedCategory,
    setSelectedCategory,
    selectedImage,
    setSelectedImage,
    ref,
    inView,
  };
};