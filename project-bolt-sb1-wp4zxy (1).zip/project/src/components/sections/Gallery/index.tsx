import React from 'react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { Section } from '../../ui/Section';
import { GalleryCategories } from './GalleryCategories';
import { GalleryItem } from './GalleryItem';
import { GalleryModal } from './GalleryModal';
import { useGallery } from './useGallery';
import { categories, galleryItems } from './galleryData';

const Gallery = () => {
  const { t } = useLanguage();
  const {
    selectedCategory,
    setSelectedCategory,
    selectedImage,
    setSelectedImage,
    ref,
    inView,
  } = useGallery();

  const filteredItems = selectedCategory === 'Todos'
    ? galleryItems
    : galleryItems.filter(item => item.category === selectedCategory);

  const selectedImageUrl = selectedImage 
    ? galleryItems.find(item => item.id === selectedImage)?.image 
    : null;

  return (
    <Section id="gallery" className="bg-obsidian-900">
      <h2 className="section-title">{t('gallery')}</h2>

      <GalleryCategories
        categories={categories}
        selectedCategory={selectedCategory}
        onCategorySelect={setSelectedCategory}
      />

      <div ref={ref} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredItems.map((item, index) => (
          <GalleryItem
            key={item.id}
            item={item}
            index={index}
            inView={inView}
            onSelect={setSelectedImage}
          />
        ))}
      </div>

      <GalleryModal
        selectedImage={selectedImageUrl}
        onClose={() => setSelectedImage(null)}
      />
    </Section>
  );
};

export default Gallery;