import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { useLanguage } from '../../../contexts/LanguageContext';
import { Section } from '../../ui/Section';
import { Button } from '../../ui/Button';

const About = () => {
  const { t } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.2,
  });

  return (
    <Section id="about" className="bg-obsidian-800">
      <div ref={ref} className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="relative h-[600px]"
        >
          <img
            src="https://images.unsplash.com/photo-1598371839696-5c5bb00bdc28?w=800&auto=format&fit=crop&q=60"
            alt="Tamara working"
            className="absolute inset-0 w-full h-full object-cover rounded-lg shadow-2xl"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-lg"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          animate={inView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <h2 className="section-title text-left">{t('about')}</h2>
          <p className="text-gray-300 mb-6 leading-relaxed">
            {t('aboutDescription1')}
          </p>
          <p className="text-gray-300 mb-8 leading-relaxed">
            {t('aboutDescription2')}
          </p>
          <Button href="#gallery" variant="primary">
            {t('exploreGallery')}
          </Button>
        </motion.div>
      </div>
    </Section>
  );
};

export default About;