import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const categories = ['Todos', 'Líneas Finas', 'Microrealismo', 'Botánico', 'Color'];

const galleryItems = [
  {
    id: 1,
    category: 'Líneas Finas',
    image: 'https://images.unsplash.com/photo-1611501275019-9b5cda994e8d?w=800&auto=format&fit=crop&q=60',
    title: 'Diseño Geométrico',
    description: 'Líneas precisas que crean patrones geométricos únicos',
  },
  {
    id: 2,
    category: 'Botánico',
    image: 'https://images.unsplash.com/photo-1610634764526-fe62fc0e4966?w=800&auto=format&fit=crop&q=60',
    title: 'Flores Silvestres',
    description: 'Composición botánica con detalles naturales',
  },
  {
    id: 3,
    category: 'Microrealismo',
    image: 'https://images.unsplash.com/photo-1612615767439-c54bc04ff37d?w=800&auto=format&fit=crop&q=60',
    title: 'Retrato Miniatura',
    description: 'Detallado trabajo de microrealismo',
  },
  {
    id: 4,
    category: 'Color',
    image: 'https://images.unsplash.com/photo-1590246814883-57c511e76523?w=800&auto=format&fit=crop&q=60',
    title: 'Acuarela Abstracta',
    description: 'Explosión de colores en estilo acuarela',
  },
];

const Gallery = () => {
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const filteredItems = selectedCategory === 'Todos'
    ? galleryItems
    : galleryItems.filter(item => item.category === selectedCategory);

  return (
    <section id="gallery" className="py-20 bg-obsidian-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="section-title">Galería</h2>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gold-400 text-black'
                  : 'bg-obsidian-800 text-gray-300 hover:bg-gold-400/20'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div
          ref={ref}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {filteredItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative cursor-pointer"
              onClick={() => setSelectedImage(item.id)}
            >
              <div className="aspect-w-3 aspect-h-4 relative overflow-hidden rounded-lg">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transform transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="text-xl font-cinzel font-bold text-gold-400 mb-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-300">
                      {item.description}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="relative max-w-4xl w-full"
          >
            <img
              src={galleryItems.find(item => item.id === selectedImage)?.image}
              alt="Selected artwork"
              className="w-full h-auto rounded-lg"
            />
          </motion.div>
        </div>
      )}
    </section>
  );
};

export default Gallery;