import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Instagram, Facebook, MessageCircle } from 'lucide-react';

const Footer = () => {
  const { t } = useLanguage();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-obsidian-800 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center space-y-4">
          <div className="flex space-x-6">
            <a href="https://instagram.com/viento_tattoos" target="_blank" rel="noopener noreferrer"
               className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
              <Instagram size={24} />
            </a>
            <a href="https://facebook.com/tamy.avila.g" target="_blank" rel="noopener noreferrer"
               className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
              <Facebook size={24} />
            </a>
            <a href="https://wa.me/14385314235" target="_blank" rel="noopener noreferrer"
               className="text-gray-300 hover:text-gold-400 transition-colors duration-300">
              <MessageCircle size={24} />
            </a>
          </div>
          <p className="text-gray-400 text-sm">
            © {currentYear} Viento Tattoos. {t('allRightsReserved')}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;