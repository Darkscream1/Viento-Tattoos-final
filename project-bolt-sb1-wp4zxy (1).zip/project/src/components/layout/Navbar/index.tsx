import React from 'react';
import { Navigation } from './Navigation';
import { MobileMenu } from './MobileMenu';
import { Logo } from './Logo';
import { useScrollEffect } from '../../../hooks/useScrollEffect';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const isScrolled = useScrollEffect();

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-obsidian-900/95 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Logo />
          <Navigation />
          <MobileMenu isOpen={isOpen} setIsOpen={setIsOpen} />
        </div>
      </div>
    </nav>
  );
};

export default Navbar;