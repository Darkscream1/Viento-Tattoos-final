import React from 'react';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { NavLinks } from './NavLinks';
import { SocialLinks } from './SocialLinks';
import { LanguageSwitcher } from '../../ui/LanguageSwitcher';

interface MobileMenuProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export const MobileMenu = ({ isOpen, setIsOpen }: MobileMenuProps) => {
  return (
    <>
      <div className="md:hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="text-gray-300 hover:text-gold-400 transition-colors duration-300"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Navigation */}
      <div className={`md:hidden fixed inset-x-0 top-20 transition-all duration-300 ${
        isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'
      } bg-obsidian-900/95 backdrop-blur-sm`}>
        <div className="px-4 pt-2 pb-8 space-y-4">
          <div className="flex flex-col space-y-4">
            <NavLinks />
          </div>
          <div className="flex items-center space-x-6 pt-4">
            <LanguageSwitcher />
            <SocialLinks />
          </div>
        </div>
      </div>
    </>
  );
};