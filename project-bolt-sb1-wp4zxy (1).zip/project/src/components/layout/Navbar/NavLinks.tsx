import React from 'react';
import { useLanguage } from '../../../contexts/LanguageContext';

export const NavLinks = () => {
  const { t } = useLanguage();
  
  const links = [
    { href: '#about', label: 'about' },
    { href: '#gallery', label: 'gallery' },
    { href: '#services', label: 'services' },
    { href: '#booking', label: 'booking' },
  ];

  return (
    <>
      {links.map(({ href, label }) => (
        <a key={href} href={href} className="nav-link">
          {t(label)}
        </a>
      ))}
    </>
  );
};