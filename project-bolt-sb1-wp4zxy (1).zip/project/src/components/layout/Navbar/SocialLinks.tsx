import React from 'react';
import { Instagram, Facebook, MessageCircle } from 'lucide-react';

const SOCIAL_LINKS = {
  instagram: 'https://www.instagram.com/viento_tattoos/',
  facebook: 'https://www.facebook.com/tamy.avila.g/',
  whatsapp: 'https://wa.me/14385314235'
};

export const SocialLinks = () => {
  return (
    <div className="flex items-center space-x-4">
      <a
        href={SOCIAL_LINKS.instagram}
        target="_blank"
        rel="noopener noreferrer"
        className="text-gray-300 hover:text-gold-400 transition-colors duration-300"
      >
        <Instagram size={20} />
      </a>
      <a
        href={SOCIAL_LINKS.facebook}
        target="_blank"
        rel="noopener noreferrer"
        className="text-gray-300 hover:text-gold-400 transition-colors duration-300"
      >
        <Facebook size={20} />
      </a>
      <a
        href={SOCIAL_LINKS.whatsapp}
        target="_blank"
        rel="noopener noreferrer"
        className="text-gray-300 hover:text-gold-400 transition-colors duration-300"
      >
        <MessageCircle size={20} />
      </a>
    </div>
  );
};