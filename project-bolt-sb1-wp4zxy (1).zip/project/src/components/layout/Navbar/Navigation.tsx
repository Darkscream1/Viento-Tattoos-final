import React from 'react';
import { useLanguage } from '../../../contexts/LanguageContext';
import { SocialLinks } from './SocialLinks';
import { NavLinks } from './NavLinks';
import { LanguageSwitcher } from '../../ui/LanguageSwitcher';

export const Navigation = () => {
  return (
    <div className="hidden md:flex items-center space-x-8">
      <NavLinks />
      <div className="flex items-center space-x-4 ml-8">
        <LanguageSwitcher />
        <SocialLinks />
      </div>
    </div>
  );
};