import React from 'react';

export const Logo = () => {
  return (
    <div className="flex-shrink-0">
      <span className="font-cinzel text-2xl font-bold metallic-text">
        Viento Tattoos
      </span>
    </div>
  );
};