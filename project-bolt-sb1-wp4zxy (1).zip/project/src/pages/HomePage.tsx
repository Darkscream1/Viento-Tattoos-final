import React from 'react';
import Hero from '../components/sections/Hero';
import About from '../components/sections/About';
import Gallery from '../components/sections/Gallery';
import Services from '../components/sections/Services';
import Booking from '../components/sections/Booking';

const HomePage = () => {
  return (
    <>
      <Hero />
      <About />
      <Gallery />
      <Services />
      <Booking />
    </>
  );
};

export default HomePage;