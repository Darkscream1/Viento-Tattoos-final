import React from 'react';
import { LanguageProvider } from './contexts/LanguageContext';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';

function App() {
  return (
    <LanguageProvider>
      <Layout>
        <HomePage />
      </Layout>
    </LanguageProvider>
  );
}

export default App;