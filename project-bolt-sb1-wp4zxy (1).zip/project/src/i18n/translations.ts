export const translations = {
  es: {
    // Navbar & Common
    about: 'Sobre mí',
    gallery: 'Galería',
    services: 'Servicios',
    booking: 'Reservas',
    allRightsReserved: 'Todos los derechos reservados',
    
    // Hero
    heroTitle: 'Tu piel, tu historia',
    heroSubtitle: 'Convertida en arte. Creaciones únicas que cuentan quién eres.',
    bookNow: 'Reserva tu cita ahora',
    
    // About
    aboutDescription1: 'Soy Tamara, artista visual y tatuadora. Mi formación en la Universidad Católica de Chile me brindó una sólida base artística que complementa perfectamente mi pasión por el tatuaje.',
    aboutDescription2: 'Con más de cinco años de experiencia, me he especializado en técnicas como líneas finas, microrealismo, diseños botánicos y trabajos en color. Cada tatuaje es una oportunidad para crear una obra de arte única que refleje tu historia personal.',
    exploreGallery: 'Explora mi Galería',
    
    // Services
    customDesigns: 'Diseños Personalizados',
    customDesignsDesc: 'Transforma tus ideas en arte único para tu piel',
    fineLines: 'Líneas Finas',
    fineLinesDesc: 'Precisión y delicadeza en cada trazo',
    microrealism: 'Microrealismo',
    microrealismDesc: 'Detalles sorprendentes en espacios pequeños',
    botanical: 'Botánico y Color',
    botanicalDesc: 'Inspiración natural con vibrantes toques artísticos',
    
    // Gallery
    allCategories: 'Todos',
    viewDetails: 'Ver detalles',
    
    // Booking
    bookingTitle: '¿Tienes preguntas o quieres agendar tu cita?',
    contactMe: 'Escríbeme directamente aquí',
  },
  fr: {
    // Navbar & Common
    about: 'À propos',
    gallery: 'Galerie',
    services: 'Services',
    booking: 'Réservations',
    allRightsReserved: 'Tous droits réservés',
    
    // Hero
    heroTitle: 'Votre peau, votre histoire',
    heroSubtitle: 'Transformée en art. Des créations uniques qui racontent qui vous êtes.',
    bookNow: 'Réservez maintenant',
    
    // About
    aboutDescription1: 'Je suis Tamara, artiste visuelle et tatoueuse. Ma formation à l\'Université Catholique du Chili m\'a donné une solide base artistique qui complète parfaitement ma passion pour le tatouage.',
    aboutDescription2: 'Avec plus de cinq ans d\'expérience, je me suis spécialisée dans les techniques telles que les lignes fines, le microréalisme, les motifs botaniques et le travail en couleur. Chaque tatouage est une opportunité de créer une œuvre d\'art unique qui reflète votre histoire personnelle.',
    exploreGallery: 'Explorez ma Galerie',
    
    // Services
    customDesigns: 'Designs Personnalisés',
    customDesignsDesc: 'Transformez vos idées en art unique sur votre peau',
    fineLines: 'Lignes Fines',
    fineLinesDesc: 'Précision et délicatesse dans chaque trait',
    microrealism: 'Microréalisme',
    microrealismDesc: 'Des détails étonnants dans de petits espaces',
    botanical: 'Botanique et Couleur',
    botanicalDesc: 'Inspiration naturelle avec des touches artistiques vibrantes',
    
    // Gallery
    allCategories: 'Tous',
    viewDetails: 'Voir les détails',
    
    // Booking
    bookingTitle: 'Des questions ou envie de prendre rendez-vous ?',
    contactMe: 'Contactez-moi directement ici',
  },
  en: {
    // Navbar & Common
    about: 'About',
    gallery: 'Gallery',
    services: 'Services',
    booking: 'Book Now',
    allRightsReserved: 'All rights reserved',
    
    // Hero
    heroTitle: 'Your skin, your story',
    heroSubtitle: 'Transformed into art. Unique creations that tell who you are.',
    bookNow: 'Book Now',
    
    // About
    aboutDescription1: 'I\'m Tamara, a visual artist and tattoo artist. My education at the Catholic University of Chile gave me a solid artistic foundation that perfectly complements my passion for tattooing.',
    aboutDescription2: 'With over five years of experience, I\'ve specialized in techniques such as fine lines, microrealism, botanical designs, and color work. Each tattoo is an opportunity to create a unique piece of art that reflects your personal story.',
    exploreGallery: 'Explore my Gallery',
    
    // Services
    customDesigns: 'Custom Designs',
    customDesignsDesc: 'Transform your ideas into unique art on your skin',
    fineLines: 'Fine Lines',
    fineLinesDesc: 'Precision and delicacy in every stroke',
    microrealism: 'Microrealism',
    microrealismDesc: 'Amazing details in small spaces',
    botanical: 'Botanical & Color',
    botanicalDesc: 'Natural inspiration with vibrant artistic touches',
    
    // Gallery
    allCategories: 'All',
    viewDetails: 'View details',
    
    // Booking
    bookingTitle: 'Have questions or want to book an appointment?',
    contactMe: 'Contact me directly here',
  },
};